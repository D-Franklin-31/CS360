package com.example.franklininventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    Database db;
    EditText usernameField, passwordField;
    Button loginBtn, registerBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Make sure your layout name matches

        db = new Database(this);
        usernameField = findViewById(R.id.editTextUsername);
        passwordField = findViewById(R.id.editTextPassword);
        loginBtn = findViewById(R.id.buttonLogin);
        registerBtn = findViewById(R.id.buttonCreateAccount);

        // Login button
        loginBtn.setOnClickListener(v -> {
            String user = usernameField.getText().toString();
            String pass = passwordField.getText().toString();

            // Check against DB
            if (db.checkUser(user, pass)) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, DataDisplayActivity.class)); // Replace with your actual next screen
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // Register button
        registerBtn.setOnClickListener(v -> {
            String user = usernameField.getText().toString();
            String pass = passwordField.getText().toString();

            // Save new user to DB
            if (db.insertUser(user, pass)) {
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Account creation failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}