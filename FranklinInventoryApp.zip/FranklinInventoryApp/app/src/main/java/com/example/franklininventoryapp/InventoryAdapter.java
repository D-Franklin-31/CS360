package com.example.franklininventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

// Adapter class to bind inventory data to RecyclerView rows
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private Context context;
    private ArrayList<InventoryItem> itemList;

    // Listener interface for delete button action
    private OnDeleteClickListener deleteClickListener;

    // Listener interface for edit button action
    private OnEditClickListener editClickListener;

    // Custom interface for delete functionality
    public interface OnDeleteClickListener {
        void onDeleteClick(int itemId);
    }

    // Custom interface for edit functionality
    public interface OnEditClickListener {
        void onEditClick(InventoryItem item);
    }

    // Constructor takes context, data list, and both listeners
    public InventoryAdapter(Context context, ArrayList<InventoryItem> itemList,
                            OnDeleteClickListener deleteClickListener,
                            OnEditClickListener editClickListener) {
        this.context = context;
        this.itemList = itemList;
        this.deleteClickListener = deleteClickListener;
        this.editClickListener = editClickListener;
    }

    // Create a new ViewHolder when needed
    @Override
    public InventoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate the layout for a single row in the RecyclerView
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_item, parent, false);
        return new InventoryViewHolder(view);
    }

    // Bind data to the views in the row
    @Override
    public void onBindViewHolder(InventoryViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);

        // Set text values from the data model
        holder.name.setText(item.name);
        holder.quantity.setText(String.valueOf(item.quantity));
        holder.date.setText(item.date);

        // Set click listener for delete button
        holder.deleteBtn.setOnClickListener(v -> deleteClickListener.onDeleteClick(item.id));

        // Set click listener for edit button
        holder.editBtn.setOnClickListener(v -> editClickListener.onEditClick(item));
    }

    // Return the total number of items
    @Override
    public int getItemCount() {
        return itemList.size();
    }

    // Called to refresh the data in the RecyclerView
    public void updateData(ArrayList<InventoryItem> newList) {
        itemList = newList;
        notifyDataSetChanged(); // Notify adapter of data change
    }

    // ViewHolder class holds view references for a single row
    public static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView name, quantity, date;
        Button deleteBtn, editBtn;

        public InventoryViewHolder(View itemView) {
            super(itemView);

            // Get references to TextViews and Buttons in layout
            name = itemView.findViewById(R.id.textViewItemName);
            quantity = itemView.findViewById(R.id.textViewQuantity);
            date = itemView.findViewById(R.id.textViewDate);
            deleteBtn = itemView.findViewById(R.id.buttonDeleteItem);
            editBtn = itemView.findViewById(R.id.buttonEditItem);
        }
    }
}
