package com.example.franklininventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DataDisplayActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1001;

    private Database dbHelper;
    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private ArrayList<InventoryItem> inventoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dbHelper = new Database(this);
        recyclerView = findViewById(R.id.recyclerViewInventory);
        Button addButton = findViewById(R.id.buttonAddItem);
        Button smsButton = findViewById(R.id.buttonSendSms); // Button in layout for SMS

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadInventoryData();

        adapter = new InventoryAdapter(
                this,
                inventoryList,
                itemId -> {
                    dbHelper.deleteInventoryItem(itemId);
                    loadInventoryData();
                    adapter.updateData(inventoryList);
                },
                item -> {
                    Intent intent = new Intent(this, AddItemActivity.class);
                    intent.putExtra("itemId", item.id);
                    intent.putExtra("name", item.name);
                    intent.putExtra("quantity", item.quantity);
                    intent.putExtra("date", item.date);
                    startActivity(intent);
                }
        );

        recyclerView.setAdapter(adapter);

        addButton.setOnClickListener(v -> {
            startActivity(new Intent(this, AddItemActivity.class));
        });

        smsButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                sendLowInventorySms();
            }
        });
    }

    // Load inventory data from DB and show it in the RecyclerView
    private void loadInventoryData() {
        inventoryList = new ArrayList<>();
        Cursor cursor = dbHelper.getAllInventoryItems();

        // Loop through DB results
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));

                // Add to list
                inventoryList.add(new InventoryItem(id, name, quantity, date));
            } while (cursor.moveToNext());
        }

        cursor.close();
    }

    // Send SMS if any inventory items are low
    private void sendLowInventorySms() {
        StringBuilder message = new StringBuilder("Low Inventory Items:\n");

        // Collect low stock items
        for (InventoryItem item : inventoryList) {
            if (item.quantity < 5) {
                message.append(item.name).append(" - Qty: ").append(item.quantity).append("\n");
            }
        }
        // notify no items
        if (message.toString().equals("Low Inventory Items:\n")) {
            Toast.makeText(this, "No low inventory items.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("1234567890", null, message.toString(), null, null); // Replace with real number for testing
            Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendLowInventorySms();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
